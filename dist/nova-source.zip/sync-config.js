// Safe placeholder for source distribution. Configure Supabase locally to enable cloud sync.
window.BOOKMARK_SYNC_CONFIG = {};
